class Pessoa{
    constructor(nome, idade){
       this.nome = nome;
       this.idade = idade;
    }

    clone(){
        return Object.assign(Object.create(Object.getPrototypeOf(this)), this);
    }
}

class PessoaManager{
    constructor(){
        this.pessoas = {};
    }

    addPessoa(nome, idade, id){
        const pessoa = new Pessoa(nome, idade);
        this.pessoas[id] = pessoa;
    }

    getPessoa(id){
        return this.pessoas[id].clone();
    }

}

const manager = new PessoaManager();

// #######################################################################################
// Adicionar duas pessoas

manager.addPessoa('Guilherme', 19, 1);
manager.addPessoa('Marcos',30, 2);
manager.addPessoa('Luana',18, 3);
manager.addPessoa('Amanda',20,4);

// Clonar a pessoa de id=1

const pessoa1 = manager.getPessoa(1);
const pessoa2 = manager.getPessoa(1);

// Modificar a idade de pessoa clonada 

pessoa1.idade = 50;
pessoa2.nome = "Guilherme de Souza";
pessoa2.idade = 20

//Imprime as pessoas 

console.log(manager.getPessoa(1));
console.log(manager.getPessoa(2));
console.log(manager.getPessoa(3));
console.log(manager.getPessoa(4));
console.log(pessoa1)
console.log(pessoa2)